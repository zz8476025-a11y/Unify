'use client'

import { useMemo, useState } from 'react'
import {
  AudioLines, ChevronDown, CircleHelp, Clapperboard, Cloud, Command, Download,
  Film, FolderOpen, Gauge, Grid2X2, Image as ImageIcon, Layers3, Library, Maximize2,
  Mic2, MonitorPlay, MousePointer2, Music2, Pause, Play, Plus, Redo2, Scissors,
  Search, Settings2, Sparkles, Split, Square, Star, Trash2, Undo2, Upload, Wand2,
  ZoomIn, ZoomOut,
} from 'lucide-react'

const assets = [
  { name: 'Mountain sunrise', type: 'VIDEO', duration: '00:18', tone: 'asset-sky' },
  { name: 'City timelapse', type: 'VIDEO', duration: '00:12', tone: 'asset-city' },
  { name: 'Ocean waves', type: 'VIDEO', duration: '00:24', tone: 'asset-ocean' },
  { name: 'Cinematic whoosh', type: 'AUDIO', duration: '00:04', tone: 'asset-audio' },
  { name: 'Paper texture', type: 'IMAGE', duration: '—', tone: 'asset-paper' },
]

const clips = [
  { name: 'Mountain sunrise', start: 3, width: 22, tone: 'clip-sky', track: 'V1' },
  { name: 'City timelapse', start: 26, width: 17, tone: 'clip-city', track: 'V1' },
  { name: 'Ocean waves', start: 44, width: 28, tone: 'clip-ocean', track: 'V1' },
  { name: 'Cinematic whoosh', start: 14, width: 18, tone: 'clip-audio', track: 'A1' },
  { name: 'Voiceover', start: 36, width: 27, tone: 'clip-voice', track: 'A1' },
]

function IconButton({ label, children, active = false, onClick }: { label: string; children: React.ReactNode; active?: boolean; onClick?: () => void }) {
  return <button aria-label={label} title={label} onClick={onClick} className={`icon-button ${active ? 'is-active' : ''}`}>{children}</button>
}

export default function Page() {
  const [activeTab, setActiveTab] = useState('Media')
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState('Mountain sunrise')
  const [playing, setPlaying] = useState(false)
  const [time, setTime] = useState(12)
  const [zoom, setZoom] = useState(1)
  const [exportOpen, setExportOpen] = useState(false)
  const filtered = useMemo(() => assets.filter((asset) => asset.name.toLowerCase().includes(query.toLowerCase())), [query])

  return (
    <main className="editor-app">
      <header className="topbar">
        <div className="brand"><div className="brand-mark"><Film /></div><span>UNIFY</span><b>VIDEO EDITOR</b></div>
        <div className="project-name"><span>Untitled Project</span><span className="muted">/</span><span className="muted">16:9 · 4K Preview</span><ChevronDown size={14} /></div>
        <div className="top-actions"><span className="saved"><Cloud size={14} /> All changes saved</span><IconButton label="Undo"><Undo2 /></IconButton><IconButton label="Redo"><Redo2 /></IconButton><IconButton label="Project settings"><Settings2 /></IconButton><button className="export-button" onClick={() => setExportOpen(true)}><Download size={16} /> Export</button><div className="avatar">AK</div></div>
      </header>

      <section className="workspace">
        <aside className="toolrail">
          {[[MousePointer2, 'Select'], [Scissors, 'Edit'], [AudioLines, 'Audio'], [Wand2, 'Effects'], [Layers3, 'Titles'], [Grid2X2, 'Transitions'], [Library, 'Stock']].map(([Icon, label], index) => <button key={label as string} className={`rail-item ${index === 0 ? 'selected' : ''}`} title={label as string}><Icon size={19} /><span>{label as string}</span></button>)}
          <div className="rail-spacer" /><button className="rail-item" title="Help"><CircleHelp size={19} /></button>
        </aside>

        <aside className="asset-panel">
          <div className="panel-heading"><div><p className="eyebrow">PROJECT LIBRARY</p><h2>Assets</h2></div><IconButton label="Add media"><Plus /></IconButton></div>
          <div className="asset-tabs">{['Media', 'Audio', 'Titles'].map((tab) => <button key={tab} onClick={() => setActiveTab(tab)} className={activeTab === tab ? 'active' : ''}>{tab}</button>)}</div>
          <div className="search-box"><Search size={15} /><input aria-label="Search assets" placeholder="Search assets" value={query} onChange={(event) => setQuery(event.target.value)} /><kbd>⌘ K</kbd></div>
          <button className="import-card"><Upload size={20} /><span>Import media</span><small>Drop files here or browse</small></button>
          <div className="asset-list">{filtered.map((asset) => <button key={asset.name} className={`asset-item ${selected === asset.name ? 'selected' : ''}`} onClick={() => setSelected(asset.name)}><div className={`asset-thumb ${asset.tone}`}><span>{asset.type === 'AUDIO' ? <AudioLines size={18} /> : asset.type === 'IMAGE' ? <ImageIcon size={18} /> : <Play size={16} fill="currentColor" />}</span><em>{asset.duration}</em></div><div className="asset-copy"><strong>{asset.name}</strong><small>{asset.type}</small></div><Star size={14} className="star" /></button>)}</div>
          <div className="storage"><div><span>Cloud storage</span><b>2.4 GB <small>/ 10 GB</small></b></div><div className="progress"><i /></div></div>
        </aside>

        <section className="center-stage">
          <div className="stage-toolbar"><div className="breadcrumbs"><MonitorPlay size={16} /> Preview <span>/</span> <b>Sequence 01</b></div><div className="stage-tools"><span className="live-dot" /> <span>Preview quality</span><button>1/2</button><IconButton label="Fullscreen"><Maximize2 /></IconButton></div></div>
          <div className="preview-wrap"><div className="preview"><div className="preview-image"><div className="preview-gradient" /><div className="preview-title"><small>WANDER</small><strong>FIND YOUR<br />NEXT HORIZON</strong></div><div className="preview-meta"><span>UNIFY ORIGINALS</span><span>2027</span></div></div><div className="safe-area" /></div></div>
          <div className="transport"><span className="timecode">00:{String(time).padStart(2, '0')}:12 <i>/</i> 01:24:08</span><div className="transport-controls"><IconButton label="Previous clip"><Undo2 /></IconButton><button className="play-button" onClick={() => { setPlaying(!playing); if (!playing) setTime((value) => Math.min(value + 1, 84)) }}>{playing ? <Pause fill="currentColor" /> : <Play fill="currentColor" />}</button><IconButton label="Next clip"><Redo2 /></IconButton></div><div className="transport-right"><span>100%</span><IconButton label="Mute"><AudioLines /></IconButton><IconButton label="Monitor settings"><Settings2 /></IconButton></div></div>
          <div className="timeline"><div className="timeline-header"><span>Timeline</span><div className="timeline-actions"><button onClick={() => setZoom(Math.max(.7, zoom - .2))}><ZoomOut size={15} /></button><span>{Math.round(zoom * 100)}%</span><button onClick={() => setZoom(Math.min(1.5, zoom + .2))}><ZoomIn size={15} /></button><button><Gauge size={15} /> Fit</button></div></div><div className="ruler"><span>00:00</span><span>00:15</span><span>00:30</span><span>00:45</span><span>01:00</span><span>01:15</span></div><div className="track-area"><div className="playhead" style={{ left: `${12 + time * 0.85}%` }}><span /></div>{['V1', 'V2', 'A1', 'A2'].map((track) => <div className="track" key={track}><div className="track-label">{track}<span>{track.startsWith('A') ? <AudioLines size={12} /> : <Film size={12} />}</span></div><div className="track-lane">{clips.filter((clip) => clip.track === track).map((clip) => <button key={clip.name} onClick={() => setSelected(clip.name)} className={`clip ${clip.tone} ${selected === clip.name ? 'clip-selected' : ''}`} style={{ left: `${clip.start * zoom}%`, width: `${clip.width * zoom}%` }}><span>{clip.name}</span><div className="waveform">{Array.from({ length: 18 }).map((_, index) => <i key={index} style={{ height: `${20 + ((index * 17) % 65)}%` }} />)}</div></button>)}</div></div>)}</div></div>
        </section>

        <aside className="inspector"><div className="inspector-tabs"><button className="active">Properties</button><button>Effects</button><button>Motion</button></div><div className="inspector-content"><div className="selected-heading"><div className="mini-thumb clip-sky"><Play size={14} fill="currentColor" /></div><div><small>VIDEO CLIP</small><h3>{selected}</h3></div><IconButton label="More clip options"><Command /></IconButton></div><InspectorSection title="Transform"><Control label="Position" values={['960', '540']} /><Control label="Scale" values={['100%']} /><Control label="Rotation" values={['0°']} /></InspectorSection><InspectorSection title="Speed & Duration"><Control label="Speed" values={['1.00x']} /><div className="toggle-row"><span>Ripple edit</span><button className="switch on"><i /></button></div></InspectorSection><InspectorSection title="Color"><div className="color-row"><span>Temperature</span><b>0</b></div><input type="range" defaultValue="50" /><div className="color-row"><span>Saturation</span><b>12</b></div><input type="range" defaultValue="58" /></InspectorSection><button className="ai-button"><Sparkles size={16} /><span><b>Enhance with AI</b><small>Auto color, clarity & denoise</small></span><ChevronDown size={15} /></button></div></aside>
      </section>

      {exportOpen && <div className="modal-backdrop" onClick={() => setExportOpen(false)}><div className="export-modal" onClick={(event) => event.stopPropagation()}><div className="modal-head"><div><p className="eyebrow">FINAL OUTPUT</p><h2>Export your story</h2><p>Enhance your footage with the Unify processing engine.</p></div><IconButton label="Close" onClick={() => setExportOpen(false)}><Square /></IconButton></div><div className="export-grid"><label>Resolution<select defaultValue="4K"><option>4K · 3840 × 2160</option><option>8K · 7680 × 4320</option><option>1080p · 1920 × 1080</option></select></label><label>Frame rate<select defaultValue="24 fps"><option>24 fps</option><option>30 fps</option><option>60 fps</option></select></label></div><div className="upscale-card"><Sparkles size={18} /><div><b>AI Super Resolution</b><p>Reconstruct detail from low-res source frames for clean 4K+ output.</p></div><button className="switch on"><i /></button></div><div className="export-options"><label><input type="checkbox" defaultChecked /> Frame interpolation</label><label><input type="checkbox" defaultChecked /> AI audio denoise</label><label><input type="checkbox" /> HDR color space</label></div><button className="start-export" onClick={() => setExportOpen(false)}><Download size={17} /> Start export <span>Est. 04:32</span></button></div></div>}
    </main>
  )
}

function InspectorSection({ title, children }: { title: string; children: React.ReactNode }) { return <section className="inspector-section"><div className="section-title"><b>{title}</b><ChevronDown size={14} /></div>{children}</section> }
function Control({ label, values }: { label: string; values: string[] }) { return <div className="control-row"><span>{label}</span><div>{values.map((value) => <button key={value}>{value}</button>)}</div></div> }

